export interface Product {
  id: string;
  name: string;
  category: string;
  originalPrice: number;
  discountPrice: number;
  discountPercentage: number;
  dosage: string;
  packaging: string;
  image: string;
  badge?: string;
  rating: number;
  soldCount: number;
  inStock: boolean;
  description: string;
  bpomNumber: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  badgeText: string;
  features: string[];
  actionLabel: string;
}

export interface PrescriptionSubmission {
  patientName: string;
  phone: string;
  patientAge: string;
  deliveryType: "instant" | "sameday" | "pickup";
  deliveryAddress: string;
  allergyNotes: string;
  imageFile?: File | null;
  imagePreviewUrl?: string;
}

export interface ConsultationRequest {
  patientName: string;
  phone: string;
  symptomCategory: string;
  ageCategory: string;
  description: string;
  urgency: "normal" | "urgent";
}
