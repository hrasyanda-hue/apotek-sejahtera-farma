import React, { useState } from "react";
import { Navbar } from "./components/Navbar";
import { HeroSection } from "./components/HeroSection";
import { ServicesSection } from "./components/ServicesSection";
import { ProductsSection } from "./components/ProductsSection";
import { WhyChooseUs } from "./components/WhyChooseUs";
import { Footer } from "./components/Footer";
import { WhatsAppFAB } from "./components/WhatsAppFAB";
import { PrescriptionModal } from "./components/PrescriptionModal";
import { ConsultationModal } from "./components/ConsultationModal";
import { HealthCheckerModal } from "./components/HealthCheckerModal";
import { CartDrawer } from "./components/CartDrawer";
import { Toast } from "./components/Toast";
import { CartItem, Product } from "./types";

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isPrescriptionOpen, setIsPrescriptionOpen] = useState(false);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [isHealthCheckerOpen, setIsHealthCheckerOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setToastMessage(`"${product.name}" ditambahkan ke keranjang belanja.`);
  };

  const handleQuickBuy = (product: Product) => {
    handleAddToCart(product, 1);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const scrollToProducts = () => {
    const el = document.getElementById("produk");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 selection:bg-blue-900 selection:text-white">
      
      {/* Toast Notification */}
      <Toast 
        message={toastMessage} 
        onClose={() => setToastMessage(null)} 
      />

      {/* Navigation Bar */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenConsultation={() => setIsConsultationOpen(true)}
        onOpenPrescription={() => setIsPrescriptionOpen(true)}
        onOpenHealthChecker={() => setIsHealthCheckerOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        
        {/* 1. Hero Section */}
        <HeroSection
          onOpenPrescription={() => setIsPrescriptionOpen(true)}
          onOpenConsultation={() => setIsConsultationOpen(true)}
          onScrollToProducts={scrollToProducts}
        />

        {/* 2. Layanan Kami (4 Grid Cards with hover effects) */}
        <ServicesSection
          onOpenPrescription={() => setIsPrescriptionOpen(true)}
          onOpenConsultation={() => setIsConsultationOpen(true)}
          onOpenHealthChecker={() => setIsHealthCheckerOpen(true)}
          onOpenDeliveryInfo={() => setIsPrescriptionOpen(true)}
        />

        {/* 3. Produk & Promo Mingguan (Grid + Filter + Discounted prices + Beli) */}
        <ProductsSection
          onAddToCart={handleAddToCart}
          onQuickBuy={handleQuickBuy}
        />

        {/* 4. Nilai Plus (Mengapa Kami? - 3 horizontal key pillars) */}
        <WhyChooseUs />

      </main>

      {/* 5. Footer */}
      <Footer
        onOpenPrescription={() => setIsPrescriptionOpen(true)}
        onOpenConsultation={() => setIsConsultationOpen(true)}
        onOpenHealthChecker={() => setIsHealthCheckerOpen(true)}
      />

      {/* 6. Floating Action Button (FAB) berlogo WhatsApp */}
      <WhatsAppFAB
        onOpenPrescription={() => setIsPrescriptionOpen(true)}
        onOpenConsultation={() => setIsConsultationOpen(true)}
      />

      {/* Interactive Modals */}
      <PrescriptionModal
        isOpen={isPrescriptionOpen}
        onClose={() => setIsPrescriptionOpen(false)}
        onSuccessToast={(msg) => setToastMessage(msg)}
      />

      <ConsultationModal
        isOpen={isConsultationOpen}
        onClose={() => setIsConsultationOpen(false)}
        onSuccessToast={(msg) => setToastMessage(msg)}
      />

      <HealthCheckerModal
        isOpen={isHealthCheckerOpen}
        onClose={() => setIsHealthCheckerOpen(false)}
        onOpenConsultation={() => setIsConsultationOpen(true)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

    </div>
  );
}
