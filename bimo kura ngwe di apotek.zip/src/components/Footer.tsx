import React from "react";
import { 
  HeartHandshake, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldCheck, 
  Award, 
  ExternalLink,
  ChevronRight,
  ArrowUp
} from "lucide-react";
import { PHARMACY_PROFILE } from "../data/mockData";

interface FooterProps {
  onOpenPrescription: () => void;
  onOpenConsultation: () => void;
  onOpenHealthChecker: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPrescription,
  onOpenConsultation,
  onOpenHealthChecker
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer id="kontak" className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-14 border-b border-slate-800">
          
          {/* Col 1: Brand & Licenses (5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
                <HeartHandshake className="w-6 h-6 text-white" />
              </div>
              <div className="flex items-center gap-1">
                <span className="font-['Outfit',sans-serif] text-2xl font-extrabold text-white tracking-tight">
                  Apotek
                </span>
                <span className="font-['Outfit',sans-serif] text-2xl font-extrabold text-blue-400">
                  Sejahtera<span className="text-emerald-400"> Farma</span>
                </span>
              </div>
            </div>

            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              {PHARMACY_PROFILE.tagline}. Melayani kebutuhan obat resep, suplemen kesehatan berlisensi, 
              dan konsultasi langsung dengan apoteker 24 jam non-stop.
            </p>

            <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700/60 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2 font-semibold text-blue-300">
                <Award className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Izin Resmi Pelayanan Kefarmasian</span>
              </div>
              <p className="text-slate-400">
                • {PHARMACY_PROFILE.siaNumber}
              </p>
              <p className="text-slate-400">
                • Penanggung Jawab: {PHARMACY_PROFILE.sipaLeadPharmacist}
              </p>
            </div>
          </div>

          {/* Col 2: Layanan Cepat (3 cols) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-['Outfit',sans-serif] text-sm font-bold uppercase tracking-wider text-white">
              Layanan Utama
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={onOpenPrescription}
                  className="hover:text-white transition-colors flex items-center gap-2 text-slate-400 hover:translate-x-1 duration-200"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  <span>Tebus Resep Dokter Online</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenConsultation}
                  className="hover:text-white transition-colors flex items-center gap-2 text-slate-400 hover:translate-x-1 duration-200"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  <span>Konsultasi Apoteker (Gratis)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenHealthChecker}
                  className="hover:text-white transition-colors flex items-center gap-2 text-slate-400 hover:translate-x-1 duration-200"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  <span>Cek Tensi, Gula & Kolesterol</span>
                </button>
              </li>
              <li>
                <a
                  href="#produk"
                  className="hover:text-white transition-colors flex items-center gap-2 text-slate-400 hover:translate-x-1 duration-200"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  <span>Katalog Produk & Promo Mingguan</span>
                </a>
              </li>
              <li>
                <a
                  href="#mengapa-kami"
                  className="hover:text-white transition-colors flex items-center gap-2 text-slate-400 hover:translate-x-1 duration-200"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                  <span>Standar Mutu & Garansi Keaslian</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Informasi Kontak & Jam (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="font-['Outfit',sans-serif] text-sm font-bold uppercase tracking-wider text-white">
              Informasi & Kontak Apotek
            </h4>
            
            <div className="space-y-3 text-sm text-slate-400">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-1" />
                <span>{PHARMACY_PROFILE.address}</span>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-1" />
                <span className="text-emerald-300 font-semibold">{PHARMACY_PROFILE.operationalHours}</span>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <a 
                  href={`tel:${PHARMACY_PROFILE.phone}`}
                  className="hover:text-white transition-colors font-mono"
                >
                  {PHARMACY_PROFILE.phone}
                </a>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-400 shrink-0" />
                <a 
                  href={`mailto:${PHARMACY_PROFILE.email}`}
                  className="hover:text-white transition-colors"
                >
                  {PHARMACY_PROFILE.email}
                </a>
              </div>
            </div>

            {/* Payment methods badges */}
            <div className="pt-2">
              <span className="text-xs font-semibold text-slate-400 block mb-2">Metode Pembayaran Resmi:</span>
              <div className="flex flex-wrap gap-2 text-[11px] font-bold text-slate-300">
                <span className="bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">QRIS</span>
                <span className="bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">BCA</span>
                <span className="bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">Mandiri</span>
                <span className="bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">GoPay / OVO</span>
                <span className="bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">COD (Bayar di Tempat)</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Apotek Sejahtera Farma. Seluruh hak cipta dilindungi undang-undang.</p>
          
          <div className="flex items-center gap-6">
            <span>Privasi Pasien Terjamin</span>
            <span>Standar CDOB Farmasi</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors ml-2"
              title="Kembali ke atas"
            >
              <ArrowUp className="w-3.5 h-3.5" />
              <span>Ke Atas</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
