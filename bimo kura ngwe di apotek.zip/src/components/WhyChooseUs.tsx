import React from "react";
import { 
  ShieldCheck, 
  Award, 
  Clock, 
  Sparkles, 
  CheckCircle, 
  Building2, 
  ThermometerSnowflake, 
  HeartHandshake 
} from "lucide-react";

export const WhyChooseUs: React.FC = () => {
  const pillars = [
    {
      id: "pillar-asli",
      title: "Produk 100% Asli",
      subtitle: "Jaminan Distributor Resmi CDOB & BPOM",
      description: "Setiap obat dan suplemen diperoleh langsung dari Pedagang Besar Farmasi (PBF) resmi dengan nomor batch terdaftar dan segel produsen utuh.",
      icon: ShieldCheck,
      iconColor: "text-emerald-600",
      bgColor: "bg-emerald-50",
      accentBadge: "Garansi Asli atau Uang Kembali",
      bulletPoints: [
        "Jalur distribusi resmi bersertifikasi CDOB",
        "Penyimpanan suhu terkontrol (Cold-Chain)",
        "Tanggal kedaluwarsa panjang & transparan"
      ]
    },
    {
      id: "pillar-apoteker",
      title: "Apoteker Bersertifikat",
      subtitle: "Sarjana Farmasi Ber-SIPA Aktif",
      description: "Pelayanan kefarmasian profesional di bawah supervisi langsung apoteker berlisensi IAI (Ikatan Apoteker Indonesia) yang siap mengedukasi pasien.",
      icon: Award,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-50",
      accentBadge: "Supervisi Medis Terstandar",
      bulletPoints: [
        "Skrining interaksi & kontraindikasi obat",
        "Edukasi dosis tepat untuk anak & lansia",
        "Privasi riwayat kesehatan terjaga 100%"
      ]
    },
    {
      id: "pillar-24jam",
      title: "Buka 24/7",
      subtitle: "Siaga Darurat Siang & Malam",
      description: "Kebutuhan medis tidak mengenal waktu. Apotek kami buka 24 jam setiap hari tanpa libur dengan kesiapan armada kurir untuk kebutuhan mendesak.",
      icon: Clock,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-50",
      accentBadge: "Selalu Siap Saat Darurat",
      bulletPoints: [
        "Layanan tebus resep malam hari",
        "Pengiriman instan kilat langsung ke rumah",
        "Konsultasi darurat apoteker via WhatsApp"
      ]
    }
  ];

  return (
    <section id="mengapa-kami" className="py-20 bg-slate-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/70 text-blue-900 text-xs font-bold tracking-wide uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            Nilai Plus & Komitmen Kami
          </div>
          <h2 id="why-choose-us-heading" className="font-['Outfit',sans-serif] text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Mengapa Memilih Apotek Care+?
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Standar pelayanan kefarmasian modern dengan komitmen integritas, keamanan obat, dan kemudahan akses bagi seluruh keluarga.
          </p>
        </div>

        {/* 3 Horizontal Column Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {pillars.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <div
                key={pillar.id}
                id={pillar.id}
                className="bg-white rounded-3xl p-8 border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-slate-300 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Icon & Badge */}
                  <div className="flex items-center justify-between gap-4 mb-6">
                    <div className={`w-16 h-16 rounded-2xl ${pillar.bgColor} flex items-center justify-center shadow-xs`}>
                      <Icon className={`w-8 h-8 ${pillar.iconColor}`} />
                    </div>
                    <span className="text-[11px] font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
                      {pillar.accentBadge}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="font-['Outfit',sans-serif] text-2xl font-bold text-slate-900">
                    {pillar.title}
                  </h3>
                  <div className="text-xs font-bold text-blue-800 uppercase tracking-wider mt-1 mb-3">
                    {pillar.subtitle}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {pillar.description}
                  </p>

                  {/* Bullet points */}
                  <div className="mt-6 pt-5 border-t border-slate-100 space-y-2.5">
                    {pillar.bulletPoints.map((point, pIdx) => (
                      <div key={pIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 font-medium">
                        <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Trust Seal */}
                <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                  <span>Standar Care+ Verified</span>
                  <span className="font-mono text-slate-500">100% Aman</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pharmacy Quality Certifications Banner */}
        <div className="mt-14 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs grid grid-cols-2 md:grid-cols-4 gap-6 items-center text-center">
          <div className="space-y-1">
            <div className="font-['Outfit',sans-serif] text-2xl font-extrabold text-blue-900">15.000+</div>
            <div className="text-xs text-slate-500 font-medium">Resep Berhasil Ditebus</div>
          </div>
          <div className="space-y-1">
            <div className="font-['Outfit',sans-serif] text-2xl font-extrabold text-emerald-700">4.9 / 5.0</div>
            <div className="text-xs text-slate-500 font-medium">Kepuasan Pelanggan</div>
          </div>
          <div className="space-y-1">
            <div className="font-['Outfit',sans-serif] text-2xl font-extrabold text-purple-900">&lt; 30 Menit</div>
            <div className="text-xs text-slate-500 font-medium">Rata-rata Waktu Kirim</div>
          </div>
          <div className="space-y-1">
            <div className="font-['Outfit',sans-serif] text-2xl font-extrabold text-slate-800">100% Resmi</div>
            <div className="text-xs text-slate-500 font-medium">Izin Kemenkes & SIPA</div>
          </div>
        </div>

      </div>
    </section>
  );
};
