import React, { useState } from "react";
import { 
  X, 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  Truck, 
  AlertCircle,
  Sparkles,
  ArrowRight
} from "lucide-react";
import { PHARMACY_PROFILE } from "../data/mockData";

interface PrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessToast: (msg: string) => void;
}

export const PrescriptionModal: React.FC<PrescriptionModalProps> = ({
  isOpen,
  onClose,
  onSuccessToast
}) => {
  const [patientName, setPatientName] = useState("");
  const [phone, setPhone] = useState("");
  const [age, setAge] = useState("");
  const [deliveryType, setDeliveryType] = useState<"instant" | "sameday" | "pickup">("instant");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [allergyNotes, setAllergyNotes] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedData, setSubmittedData] = useState<{
    id: string;
    patientName: string;
    estimatedTime: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !phone) {
      alert("Mohon lengkapi Nama Pasien dan Nomor WhatsApp.");
      return;
    }

    setIsSubmitting(true);

    try {
      // Call backend API endpoint
      const response = await fetch("/api/prescription/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientName,
          phone,
          patientAge: age,
          deliveryType,
          deliveryAddress,
          allergyInfo: allergyNotes,
          hasImage: !!imagePreview
        })
      });

      const result = await response.json();

      if (result.success) {
        setSubmittedData({
          id: result.data.prescriptionId,
          patientName: result.data.patientName,
          estimatedTime: result.data.estimatedTime
        });
        onSuccessToast(`Resep ${result.data.prescriptionId} berhasil dikirim ke Apoteker!`);
      } else {
        throw new Error(result.message || "Gagal memproses resep");
      }
    } catch (err) {
      // Fallback in case of network issue
      const mockId = "RX-" + Math.floor(100000 + Math.random() * 900000);
      setSubmittedData({
        id: mockId,
        patientName,
        estimatedTime: deliveryType === "instant" ? "30 - 45 Menit" : "1 - 2 Jam"
      });
      onSuccessToast(`Resep ${mockId} berhasil diterima oleh Apoteker Sejahtera Farma!`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendViaWhatsApp = () => {
    const text = encodeURIComponent(
      `Halo Apotek Sejahtera Farma, saya ingin tebus resep dokter dengan rincian:\n` +
      `• No. Tiket: ${submittedData?.id || "Baru"}\n` +
      `• Nama Pasien: ${patientName}\n` +
      `• Usia: ${age || "-"}\n` +
      `• No. WA: ${phone}\n` +
      `• Pengiriman: ${deliveryType === "instant" ? "Kurir Instan 30 Menit" : deliveryType === "sameday" ? "Same Day" : "Ambil di Apotek"}\n` +
      `• Alamat: ${deliveryAddress || "-"}\n` +
      `• Catatan Alergi: ${allergyNotes || "Tidak ada"}\n\n` +
      `Mohon dibantu verifikasi ketersediaan dan total biayanya. Terima kasih!`
    );
    window.open(`https://wa.me/${PHARMACY_PROFILE.whatsapp.replace("+", "")}?text=${text}`, "_blank");
  };

  const resetForm = () => {
    setSubmittedData(null);
    setImagePreview(null);
    setPatientName("");
    setPhone("");
    setAge("");
    setDeliveryAddress("");
    setAllergyNotes("");
    onClose();
  };

  return (
    <div id="prescription-modal-backdrop" className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-8 relative animate-in fade-in zoom-in duration-200">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-900 to-blue-800 text-white p-6 relative">
          <button
            id="close-prescription-modal-btn"
            onClick={resetForm}
            className="absolute top-5 right-5 p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Layanan Tebus Resep Resmi SIPA
          </div>
          <h3 className="font-['Outfit',sans-serif] text-2xl font-bold">
            Tebus Resep Dokter Online
          </h3>
          <p className="text-sm text-blue-100 mt-1">
            Unggah foto resep Anda, apoteker kami akan memverifikasi dosis dan menghubungi Anda segera.
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto">
          {submittedData ? (
            /* Success View */
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-2xl font-bold font-['Outfit',sans-serif] text-slate-900">
                  Resep Berhasil Dikirim!
                </h4>
                <p className="text-slate-600 text-sm mt-1">
                  Nomor Referensi Resep: <strong className="text-blue-900 font-mono text-base">{submittedData.id}</strong>
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left text-sm space-y-2.5 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-slate-500">Pasien:</span>
                  <span className="font-bold text-slate-800">{submittedData.patientName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Estimasi Siap/Kirim:</span>
                  <span className="font-bold text-emerald-700">{submittedData.estimatedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Apoteker Pemeriksa:</span>
                  <span className="font-medium text-slate-800">apt. Sarah Pradipta, S.Farm</span>
                </div>
              </div>

              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Apoteker kami sedang menelaah kelengkapan resep & stok obat. Anda akan menerima konfirmasi via WhatsApp dalam 3-5 menit.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  id="btn-confirm-wa-prescription"
                  onClick={handleSendViaWhatsApp}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-xl text-sm shadow-md transition-colors flex items-center justify-center gap-2"
                >
                  <span>Buka Chat WhatsApp Apoteker</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={resetForm}
                  className="border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold px-6 py-3 rounded-xl text-sm transition-colors"
                >
                  Selesai
                </button>
              </div>
            </div>
          ) : (
            /* Submission Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* File Upload Zone */}
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  Foto / Dokumen Resep Dokter <span className="text-red-500">*</span>
                </label>

                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  className="border-2 border-dashed border-slate-300 hover:border-blue-700 bg-slate-50 hover:bg-blue-50/40 rounded-2xl p-6 text-center transition-all cursor-pointer relative"
                >
                  <input
                    id="prescription-file-input"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleImageChange}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />

                  {imagePreview ? (
                    <div className="space-y-2">
                      <img
                        src={imagePreview}
                        alt="Preview Resep"
                        className="max-h-40 mx-auto rounded-lg shadow-sm border border-slate-200"
                      />
                      <p className="text-xs font-semibold text-emerald-600 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Foto resep berhasil diunggah (Klik untuk mengganti)
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-12 h-12 bg-blue-100 text-blue-900 rounded-full flex items-center justify-center mx-auto">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <div className="text-sm font-bold text-slate-800">
                        Klik atau Tarik Foto Resep Dokter ke Sini
                      </div>
                      <p className="text-xs text-slate-500">
                        Format JPG, PNG, atau PDF (Maksimal 10MB). Pastikan tulisan resep dokter terbaca jelas.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Patient Details Input */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Nama Pasien <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="input-patient-name"
                    type="text"
                    required
                    placeholder="Contoh: Budi Santoso"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Nomor WhatsApp / HP <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="input-patient-phone"
                    type="tel"
                    required
                    placeholder="Contoh: 081234567890"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Usia / Berat Badan Pasien
                  </label>
                  <input
                    id="input-patient-age"
                    type="text"
                    placeholder="Contoh: 32 Tahun / 65 Kg"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Metode Pengambilan
                  </label>
                  <select
                    id="select-delivery-type"
                    value={deliveryType}
                    onChange={(e: any) => setDeliveryType(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="instant">🚀 Kurir Instan 24 Jam (30 - 45 Menit)</option>
                    <option value="sameday">📦 Kurir Same Day (1 - 3 Jam)</option>
                    <option value="pickup">🚗 Ambil di Apotek (Drive-Thru)</option>
                  </select>
                </div>
              </div>

              {deliveryType !== "pickup" && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                    Alamat Pengantaran Lengkap
                  </label>
                  <textarea
                    id="input-delivery-address"
                    rows={2}
                    placeholder="Contoh: Jl. Melati No. 12, RT 02/RW 04, Kebayoran Baru, Jakarta Selatan (Patokan dekat Minimarket)"
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Catatan Alergi Obat / Riwayat Penyakit (Opsional)
                </label>
                <input
                  id="input-allergy-notes"
                  type="text"
                  placeholder="Contoh: Alergi Penisilin / Golongan Sulfa"
                  value={allergyNotes}
                  onChange={(e) => setAllergyNotes(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              {/* Security notice */}
              <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-blue-900">
                <AlertCircle className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <span>
                  Resep Anda dijamin kerahasiaannya oleh apoteker berlisensi sesuai Undang-Undang Kesehatan dan standar kefarmasian BPOM.
                </span>
              </div>

              {/* Submit CTA */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="w-1/3 py-3 rounded-xl border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  id="btn-submit-prescription"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-2/3 py-3 bg-blue-900 hover:bg-blue-800 active:bg-blue-950 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span>Mengirim Resep...</span>
                  ) : (
                    <>
                      <FileText className="w-4 h-4 text-emerald-400" />
                      <span>Kirim Resep ke Apoteker</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
