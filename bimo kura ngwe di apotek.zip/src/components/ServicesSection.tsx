import React from "react";
import { 
  FileText, 
  UserCheck, 
  Activity, 
  Clock, 
  ArrowRight, 
  Check, 
  Sparkles,
  ShieldAlert,
  ChevronRight
} from "lucide-react";
import { SERVICES_DATA } from "../data/mockData";

interface ServicesSectionProps {
  onOpenPrescription: () => void;
  onOpenConsultation: () => void;
  onOpenHealthChecker: () => void;
  onOpenDeliveryInfo: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onOpenPrescription,
  onOpenConsultation,
  onOpenHealthChecker,
  onOpenDeliveryInfo
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "FileText":
        return <FileText className="w-7 h-7 text-blue-600" />;
      case "UserCheck":
        return <UserCheck className="w-7 h-7 text-emerald-600" />;
      case "Activity":
        return <Activity className="w-7 h-7 text-purple-600" />;
      case "Clock":
        return <Clock className="w-7 h-7 text-amber-600" />;
      default:
        return <FileText className="w-7 h-7 text-blue-600" />;
    }
  };

  const getServiceHandler = (id: string) => {
    switch (id) {
      case "tebus-resep":
        return onOpenPrescription;
      case "konsultasi-apoteker":
        return onOpenConsultation;
      case "cek-kesehatan":
        return onOpenHealthChecker;
      case "pesan-antar-24jam":
        return onOpenDeliveryInfo;
      default:
        return onOpenPrescription;
    }
  };

  return (
    <section id="layanan" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/80 text-blue-900 text-xs font-bold tracking-wide uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            Layanan Farmasi Unggulan
          </div>
          <h2 id="services-heading" className="font-['Outfit',sans-serif] text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Layanan Lengkap untuk Kesehatan Anda
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Didukung apoteker profesional ber-SIPA dan standar kefarmasian terstandarisasi untuk memberikan pelayanan yang cepat, aman, dan higienis.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-7">
          {SERVICES_DATA.map((service, index) => {
            const handleAction = getServiceHandler(service.id);
            return (
              <div
                key={service.id}
                id={`service-card-${service.id}`}
                className="group relative bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-sm hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Top Badge & Icon */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-5">
                    <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-50/70 transition-all duration-300">
                      {getIcon(service.iconName)}
                    </div>
                    <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200/60">
                      {service.badgeText}
                    </span>
                  </div>

                  <h3 className="font-['Outfit',sans-serif] text-xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors">
                    {service.title}
                  </h3>

                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Feature Bullets */}
                  <ul className="mt-5 space-y-2 border-t border-slate-100 pt-4">
                    {service.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Action Button */}
                <div className="pt-6 mt-4 border-t border-slate-100">
                  <button
                    id={`service-action-btn-${service.id}`}
                    onClick={handleAction}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 group-hover:bg-blue-900 text-slate-800 group-hover:text-white font-semibold text-xs transition-all duration-200"
                  >
                    <span>{service.actionLabel}</span>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Emergency Callout in Services */}
        <div className="mt-12 bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-blue-800">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <ShieldAlert className="w-4 h-4" />
              Kebutuhan Obat Darurat Tengah Malam?
            </div>
            <h4 className="text-xl sm:text-2xl font-bold font-['Outfit',sans-serif]">
              Layanan Siaga 24 Jam Siap Membantu Anda
            </h4>
            <p className="text-sm text-slate-300 max-w-xl">
              Tim kurir farmasi dan apoteker jaga standby 24 jam untuk pengiriman darurat resep dan obat darurat ke seluruh area.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              id="emergency-consult-button"
              onClick={onOpenConsultation}
              className="bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-md transition-colors flex items-center gap-2"
            >
              <span>Hubungi Siaga 24 Jam</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
