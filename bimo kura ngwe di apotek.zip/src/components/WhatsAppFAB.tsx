import React, { useState } from "react";
import { 
  MessageCircle, 
  X, 
  Phone, 
  ShieldAlert, 
  FileText, 
  Send, 
  Clock, 
  Sparkles 
} from "lucide-react";
import { PHARMACY_PROFILE } from "../data/mockData";

interface WhatsAppFABProps {
  onOpenPrescription: () => void;
  onOpenConsultation: () => void;
}

export const WhatsAppFAB: React.FC<WhatsAppFABProps> = ({
  onOpenPrescription,
  onOpenConsultation
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleDirectWhatsApp = (purpose: string) => {
    let message = "";
    if (purpose === "emergency") {
      message = "🚨 *DARURAT 24 JAM APOTEK SEJAHTERA FARMA*\nHalo Apoteker, saya butuh obat darurat secepatnya. Mohon respons segera.";
    } else if (purpose === "stock") {
      message = "Halo Apotek Sejahtera Farma, saya ingin menanyakan ketersediaan obat/suplemen berikut:";
    } else {
      message = "Halo Apoteker Sejahtera Farma, saya ingin berkonsultasi mengenai obat dan kesehatan.";
    }

    const url = `https://wa.me/${PHARMACY_PROFILE.whatsapp.replace("+", "")}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
    setIsOpen(false);
  };

  return (
    <div id="whatsapp-fab-container" className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Popover Menu */}
      {isOpen && (
        <div 
          id="whatsapp-fab-popover"
          className="mb-4 bg-white rounded-3xl p-5 shadow-2xl border border-slate-200/90 w-80 sm:w-88 animate-in fade-in slide-in-from-bottom-5 duration-200"
        >
          {/* Popover Header */}
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-sm">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900 font-['Outfit',sans-serif]">
                  Apoteker Sejahtera Farma
                </h4>
                <p className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Online 24 Jam Siap Melayani
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-slate-600 mb-4 leading-relaxed">
            Pilih kebutuhan Anda untuk terhubung langsung ke Apoteker jaga kami:
          </p>

          {/* Action List */}
          <div className="space-y-2">
            <button
              id="fab-action-emergency"
              onClick={() => handleDirectWhatsApp("emergency")}
              className="w-full text-left p-3 rounded-xl bg-red-50 hover:bg-red-100/80 border border-red-200/70 flex items-center gap-3 transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-red-950">Pesanan Darurat 24 Jam</div>
                <div className="text-[11px] text-red-700">Prioritas respons &lt; 1 menit</div>
              </div>
            </button>

            <button
              id="fab-action-consult"
              onClick={() => {
                setIsOpen(false);
                onOpenConsultation();
              }}
              className="w-full text-left p-3 rounded-xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/70 flex items-center gap-3 transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-900 text-white flex items-center justify-center shrink-0">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-900">Konsultasi Apoteker (Gratis)</div>
                <div className="text-[11px] text-slate-500">Tanya dosis & aturan minum</div>
              </div>
            </button>

            <button
              id="fab-action-prescription"
              onClick={() => {
                setIsOpen(false);
                onOpenPrescription();
              }}
              className="w-full text-left p-3 rounded-xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/70 flex items-center gap-3 transition-colors group"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-900">Tebus Resep Online</div>
                <div className="text-[11px] text-slate-500">Upload resep langsung di web</div>
              </div>
            </button>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            <span>WhatsApp: {PHARMACY_PROFILE.displayWhatsapp}</span>
            <button
              onClick={() => handleDirectWhatsApp("chat")}
              className="text-emerald-700 font-bold hover:underline"
            >
              Buka Chat Langsung ➔
            </button>
          </div>

        </div>
      )}

      {/* Main Floating Button */}
      <button
        id="main-floating-whatsapp-btn"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Hubungi Apoteker via WhatsApp"
        className="relative group flex items-center gap-3 bg-[#25D366] hover:bg-[#20bd5a] active:bg-[#1caa51] text-white p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl hover:shadow-emerald-500/30 transition-all duration-300 hover:scale-105"
      >
        {/* Pulsing ring */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-80"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-300 border-2 border-[#25D366]"></span>
        </span>

        {/* WhatsApp Icon SVG style */}
        <div className="w-7 h-7 flex items-center justify-center">
          <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
          </svg>
        </div>

        <div className="hidden sm:flex flex-col text-left pr-1">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-100 leading-none">
            Siaga 24 Jam
          </span>
          <span className="text-xs font-bold leading-tight">
            Chat WhatsApp
          </span>
        </div>
      </button>

    </div>
  );
};
