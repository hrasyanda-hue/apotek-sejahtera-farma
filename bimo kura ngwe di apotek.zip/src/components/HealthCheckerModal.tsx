import React from "react";
import { 
  X, 
  Activity, 
  Heart, 
  Sparkles, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  ArrowRight,
  Phone
} from "lucide-react";
import { HEALTH_CHECK_ITEMS, PHARMACY_PROFILE } from "../data/mockData";

interface HealthCheckerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenConsultation: () => void;
}

export const HealthCheckerModal: React.FC<HealthCheckerModalProps> = ({
  isOpen,
  onClose,
  onOpenConsultation
}) => {
  if (!isOpen) return null;

  const handleWhatsAppBooking = (testName: string) => {
    const text = encodeURIComponent(
      `Halo Apotek Sejahtera Farma, saya ingin menanyakan jadwal / melakukan ${testName} di apotek.\n` +
      `Mohon info ketersediaan slot dan persiapannya. Terima kasih!`
    );
    window.open(`https://wa.me/${PHARMACY_PROFILE.whatsapp.replace("+", "")}?text=${text}`, "_blank");
  };

  return (
    <div id="health-checker-modal-backdrop" className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-8 relative animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 via-purple-950 to-slate-900 text-white p-6 relative">
          <button
            id="close-health-checker-modal-btn"
            onClick={onClose}
            className="absolute top-5 right-5 p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold mb-2">
            <Activity className="w-3.5 h-3.5 text-purple-400" />
            Layanan Pemeriksaan Mandiri di Apotek
          </div>
          <h3 className="font-['Outfit',sans-serif] text-2xl font-bold">
            Pemeriksaan & Skrining Kesehatan
          </h3>
          <p className="text-sm text-purple-200 mt-1">
            Pantau parameter kesehatan vital Anda secara rutin dengan alat uji medis terkalibrasi dan pendampingan Apoteker.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 max-h-[70vh] overflow-y-auto space-y-4">
          
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <MapPin className="w-4 h-4 text-purple-700 shrink-0" />
            <span>Lokasi: {PHARMACY_PROFILE.address} (Tanpa antre panjang, hasil keluar seketika).</span>
          </div>

          <div className="space-y-3 pt-2">
            {HEALTH_CHECK_ITEMS.map((item, idx) => (
              <div 
                key={idx}
                className="bg-white border border-slate-200/90 rounded-2xl p-4 hover:border-purple-300 hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-900">{item.name}</h4>
                    <span className="text-[11px] font-extrabold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-100">
                      {item.price}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">{item.description}</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span>⏱️ Estimasi {item.duration}</span>
                    <span>•</span>
                    <span>Anjuran: {item.recommendedFor}</span>
                  </div>
                </div>

                <button
                  id={`btn-book-test-${idx}`}
                  onClick={() => handleWhatsAppBooking(item.name)}
                  className="sm:shrink-0 bg-purple-50 hover:bg-purple-900 text-purple-900 hover:text-white text-xs font-bold py-2 px-3.5 rounded-xl border border-purple-200 transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Tanya / Cek</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Consultation Note */}
          <div className="mt-6 bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-600 text-center sm:text-left">
              <strong className="text-slate-900 block">Butuh interpretasi hasil lab atau resep lanjutan?</strong>
              Apoteker kami siap memberikan konsultasi edukasi gaya hidup dan saran obat/suplemen yang sesuai.
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenConsultation();
              }}
              className="bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold py-2.5 px-4 rounded-xl shrink-0 transition-colors"
            >
              Konsultasi Sekarang
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
