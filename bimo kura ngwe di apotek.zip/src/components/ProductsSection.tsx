import React, { useState } from "react";
import { 
  ShoppingBag, 
  Star, 
  Sparkles, 
  Check, 
  Flame, 
  Search, 
  ShieldCheck, 
  Plus, 
  Minus,
  Eye
} from "lucide-react";
import { Product } from "../types";
import { PRODUCTS_DATA } from "../data/mockData";

interface ProductsSectionProps {
  onAddToCart: (product: Product, quantity?: number) => void;
  onQuickBuy: (product: Product) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({
  onAddToCart,
  onQuickBuy
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("Semua");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedProductDetail, setSelectedProductDetail] = useState<Product | null>(null);

  const categories = [
    "Semua",
    "Vitamin & Suplemen",
    "Peralatan Medis",
    "Herbal & Alami",
    "Perlindungan & Higienis"
  ];

  const filteredProducts = PRODUCTS_DATA.filter((product) => {
    const matchesCategory = selectedCategory === "Semua" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <section id="produk" className="py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200/80 text-amber-900 text-xs font-bold tracking-wide uppercase mb-3">
              <Flame className="w-4 h-4 text-amber-600 animate-pulse" />
              Promo Spesial Minggu Ini
            </div>
            <h2 id="products-heading" className="font-['Outfit',sans-serif] text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Produk & Promo Kesehatan Pilihan
            </h2>
            <p className="mt-2 text-base text-slate-600">
              Jaminan 100% produk original bergaransi resmi, segel higienis, dan tanggal kedaluwarsa panjang.
            </p>
          </div>

          {/* Quick Search */}
          <div className="w-full md:w-72 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="product-search-input"
              type="text"
              placeholder="Cari vitamin, P3K, masker..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-900 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`cat-filter-${cat.toLowerCase().replace(/\s+/g, "-")}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
                selectedCategory === cat
                  ? "bg-blue-900 text-white shadow-sm"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200/80 hover:text-slate-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-slate-50 rounded-2xl border border-slate-200">
            <p className="text-slate-500 font-medium">Tidak ada produk yang cocok dengan pencarian Anda.</p>
            <button
              onClick={() => {
                setSelectedCategory("Semua");
                setSearchQuery("");
              }}
              className="mt-3 text-sm text-blue-700 font-bold hover:underline"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                id={`product-card-${product.id}`}
                className="group bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-xs hover:shadow-xl hover:border-slate-300 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Product Image Container */}
                <div className="relative bg-slate-50 p-6 flex items-center justify-center overflow-hidden h-56 border-b border-slate-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="h-44 w-auto object-contain group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Discount Tag */}
                  <div className="absolute top-3.5 left-3.5 bg-red-600 text-white text-xs font-extrabold px-2.5 py-1 rounded-lg shadow-sm">
                    Hemat {product.discountPercentage}%
                  </div>

                  {/* Promo Badge */}
                  {product.badge && (
                    <div className="absolute top-3.5 right-3.5 bg-blue-900/90 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-0.5 rounded-md">
                      {product.badge}
                    </div>
                  )}

                  {/* Quick Detail Trigger */}
                  <button
                    onClick={() => setSelectedProductDetail(product)}
                    className="absolute bottom-3 right-3 p-2 bg-white/90 backdrop-blur-xs rounded-lg shadow-sm text-slate-700 hover:text-blue-900 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Lihat Detail Produk"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>

                {/* Product Details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Category & BPOM */}
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                      <span className="font-medium text-blue-800">{product.category}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{product.bpomNumber.split(" ")[0]} Verified</span>
                    </div>

                    {/* Product Name */}
                    <h3 className="font-['Outfit',sans-serif] text-base font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-blue-900 transition-colors">
                      {product.name}
                    </h3>

                    {/* Dosage / Packaging */}
                    <p className="text-xs text-slate-500 mt-1">
                      {product.packaging} • {product.dosage}
                    </p>

                    {/* Rating & Sold count */}
                    <div className="flex items-center gap-2 mt-2 text-xs">
                      <div className="flex items-center text-amber-500">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span className="ml-1 font-bold text-slate-800">{product.rating}</span>
                      </div>
                      <span className="text-slate-300">•</span>
                      <span className="text-slate-500">{product.soldCount}+ Terjual</span>
                    </div>
                  </div>

                  {/* Pricing & CTA */}
                  <div className="mt-5 pt-4 border-t border-slate-100">
                    <div className="flex items-baseline gap-2 mb-3">
                      <span className="font-['Outfit',sans-serif] text-xl font-extrabold text-blue-900">
                        {formatRupiah(product.discountPrice)}
                      </span>
                      <span className="text-xs text-slate-400 line-through">
                        {formatRupiah(product.originalPrice)}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        id={`btn-add-cart-${product.id}`}
                        onClick={() => onAddToCart(product, 1)}
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border border-slate-300 hover:border-blue-900 hover:bg-blue-50/60 text-slate-800 text-xs font-bold transition-colors"
                      >
                        <ShoppingBag className="w-3.5 h-3.5 text-blue-900" />
                        <span>+ Keranjang</span>
                      </button>

                      <button
                        id={`btn-buy-${product.id}`}
                        onClick={() => onQuickBuy(product)}
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 active:bg-blue-950 text-white text-xs font-bold shadow-xs transition-colors"
                      >
                        <span>Beli Sekarang</span>
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* Product Detail Modal */}
      {selectedProductDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl relative animate-in fade-in zoom-in duration-200">
            <button
              onClick={() => setSelectedProductDetail(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
            >
              ✕
            </button>

            <div className="flex flex-col sm:flex-row gap-5 items-center">
              <div className="w-36 h-36 bg-slate-50 rounded-2xl flex items-center justify-center p-2 border border-slate-100 shrink-0">
                <img
                  src={selectedProductDetail.image}
                  alt={selectedProductDetail.name}
                  className="max-h-full max-w-full object-contain"
                />
              </div>

              <div className="flex-1">
                <span className="text-xs font-bold text-blue-900 bg-blue-50 px-2.5 py-0.5 rounded-md">
                  {selectedProductDetail.category}
                </span>
                <h3 className="font-['Outfit',sans-serif] text-lg font-bold text-slate-900 mt-1">
                  {selectedProductDetail.name}
                </h3>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-extrabold text-blue-900">
                    {formatRupiah(selectedProductDetail.discountPrice)}
                  </span>
                  <span className="text-xs text-slate-400 line-through">
                    {formatRupiah(selectedProductDetail.originalPrice)}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-5 space-y-3 text-sm text-slate-600 border-t border-slate-100 pt-4">
              <p>{selectedProductDetail.description}</p>
              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl">
                <div>
                  <span className="text-slate-400 block">Nomor BPOM/Kemenkes:</span>
                  <span className="font-bold text-slate-800">{selectedProductDetail.bpomNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Kemasan & Isi:</span>
                  <span className="font-bold text-slate-800">{selectedProductDetail.packaging}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  onAddToCart(selectedProductDetail, 1);
                  setSelectedProductDetail(null);
                }}
                className="flex-1 py-3 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-sm"
              >
                Tambah ke Keranjang
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
