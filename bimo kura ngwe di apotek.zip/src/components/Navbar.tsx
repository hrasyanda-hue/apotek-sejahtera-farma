import React, { useState, useEffect } from "react";
import { 
  HeartHandshake, 
  Phone, 
  ShoppingBag, 
  Menu, 
  X, 
  Clock, 
  Sparkles, 
  ShieldCheck,
  Search
} from "lucide-react";
import { PHARMACY_PROFILE } from "../data/mockData";

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenConsultation: () => void;
  onOpenPrescription: () => void;
  onOpenHealthChecker: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenConsultation,
  onOpenPrescription,
  onOpenHealthChecker
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Layanan", href: "#layanan" },
    { label: "Produk & Promo", href: "#produk" },
    { label: "Mengapa Kami", href: "#mengapa-kami" },
    { label: "Cek Kesehatan", onClick: onOpenHealthChecker },
    { label: "Kontak", href: "#kontak" }
  ];

  return (
    <>
      {/* Top Banner Bar */}
      <div id="top-announcement-bar" className="bg-slate-900 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-medium text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Buka 24 Jam Non-Stop
            </span>
            <span className="hidden sm:inline-block text-slate-500">|</span>
            <span className="hidden sm:flex items-center gap-1 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              100% Obat Asli Berizin BPOM & Kemenkes
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-300">
            <span className="hidden md:flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              Apoteker Siaga: <strong className="text-white font-medium">apt. Sarah Pradipta, S.Farm</strong>
            </span>
            <a
              id="top-emergency-hotline"
              href={`tel:${PHARMACY_PROFILE.phone}`}
              className="flex items-center gap-1 hover:text-white transition-colors text-blue-300 font-medium"
            >
              <Phone className="w-3 h-3" />
              <span>Darurat: {PHARMACY_PROFILE.phone}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <header 
        id="main-navbar-header"
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/80 py-3" 
            : "bg-white border-b border-slate-100 py-4"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <a id="brand-logo-link" href="#" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-900 to-blue-700 flex items-center justify-center text-white shadow-md shadow-blue-900/10 group-hover:scale-105 transition-transform duration-200">
              <div className="relative">
                <HeartHandshake className="w-6 h-6 text-white" />
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-['Outfit',sans-serif] text-2xl font-extrabold tracking-tight text-slate-900">
                  Apotek
                </span>
                <span className="font-['Outfit',sans-serif] text-2xl font-extrabold tracking-tight text-blue-600">
                  Sejahtera<span className="text-emerald-500"> Farma</span>
                </span>
              </div>
              <p className="text-[10px] tracking-wider uppercase font-semibold text-slate-400 -mt-1">
                Modern & Terpercaya
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav id="desktop-nav-links" className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link, idx) => (
              link.onClick ? (
                <button
                  key={idx}
                  id={`nav-btn-${idx}`}
                  onClick={link.onClick}
                  className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-blue-900 hover:bg-slate-50 transition-colors"
                >
                  {link.label}
                </button>
              ) : (
                <a
                  key={idx}
                  id={`nav-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                  href={link.href}
                  className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-blue-900 hover:bg-slate-50 transition-colors"
                >
                  {link.label}
                </a>
              )
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-3">
            {/* Quick Cart Button */}
            <button
              id="nav-cart-button"
              onClick={onOpenCart}
              aria-label="Keranjang Belanja"
              className="relative p-2.5 rounded-xl border border-slate-200 text-slate-700 hover:text-blue-900 hover:border-blue-300 hover:bg-blue-50/50 transition-all"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span 
                  id="nav-cart-badge"
                  className="absolute -top-1.5 -right-1.5 bg-blue-600 text-white text-[11px] font-bold h-5 min-w-5 px-1 rounded-full flex items-center justify-center ring-2 ring-white shadow-sm"
                >
                  {cartCount}
                </span>
              )}
            </button>

            {/* Hubungi Apoteker Button (Primary CTA) */}
            <button
              id="nav-contact-pharmacist-btn"
              onClick={onOpenConsultation}
              className="hidden sm:flex items-center gap-2 bg-blue-900 hover:bg-blue-800 active:bg-blue-950 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-sm hover:shadow transition-all duration-200"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Hubungi Apoteker</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div id="mobile-menu-drawer" className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 mt-3 shadow-lg">
            <div className="space-y-1">
              {navLinks.map((link, idx) => (
                link.onClick ? (
                  <button
                    key={idx}
                    id={`mobile-nav-btn-${idx}`}
                    onClick={() => {
                      link.onClick();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-900 transition-colors flex items-center justify-between"
                  >
                    <span>{link.label}</span>
                    <Sparkles className="w-4 h-4 text-blue-500" />
                  </button>
                ) : (
                  <a
                    key={idx}
                    id={`mobile-nav-link-${idx}`}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-900 transition-colors"
                  >
                    {link.label}
                  </a>
                )
              ))}
            </div>

            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <button
                id="mobile-nav-tebus-resep-btn"
                onClick={() => {
                  onOpenPrescription();
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold py-2.5 rounded-xl transition-colors text-center"
              >
                Tebus Resep Sekarang
              </button>
              <button
                id="mobile-nav-consultation-btn"
                onClick={() => {
                  onOpenConsultation();
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-blue-900 hover:bg-blue-800 text-white text-sm font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Hubungi Apoteker</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
