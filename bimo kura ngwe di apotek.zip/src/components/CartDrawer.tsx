import React, { useState } from "react";
import { 
  X, 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  ShieldCheck, 
  Truck, 
  Sparkles,
  CheckCircle2
} from "lucide-react";
import { CartItem } from "../types";
import { PHARMACY_PROFILE } from "../data/mockData";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [recipientName, setRecipientName] = useState("");
  const [recipientPhone, setRecipientPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryOption, setDeliveryOption] = useState<"instant" | "regular">("instant");
  const [isCheckoutMode, setIsCheckoutMode] = useState(false);
  const [orderComplete, setOrderComplete] = useState<string | null>(null);

  if (!isOpen) return null;

  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0
    }).format(num);
  };

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.discountPrice * item.quantity,
    0
  );

  const deliveryFee = subtotal > 150000 ? 0 : deliveryOption === "instant" ? 15000 : 10000;
  const grandTotal = subtotal + deliveryFee;

  const handleCheckoutViaWhatsApp = () => {
    if (!recipientName || !recipientPhone) {
      alert("Mohon masukkan nama dan nomor WhatsApp Anda.");
      return;
    }

    const orderId = "ORD-" + Math.floor(100000 + Math.random() * 900000);
    
    let itemsText = "";
    cartItems.forEach((item, idx) => {
      itemsText += `${idx + 1}. ${item.product.name} (${item.quantity}x) = ${formatRupiah(item.product.discountPrice * item.quantity)}\n`;
    });

    const message = encodeURIComponent(
      `Halo Apotek Sejahtera Farma, saya ingin memesan produk kesehatan:\n\n` +
      `📦 ID Pesanan: ${orderId}\n` +
      `👤 Nama Pemesan: ${recipientName}\n` +
      `📱 No. WhatsApp: ${recipientPhone}\n` +
      `📍 Alamat Pengiriman: ${deliveryAddress || "Ambil di Apotek"}\n` +
      `🚚 Opsi Pengiriman: ${deliveryOption === "instant" ? "Kurir Instan 24 Jam" : "Reguler"}\n\n` +
      `🛒 DAFTAR PRODUK:\n${itemsText}\n` +
      `Subtotal: ${formatRupiah(subtotal)}\n` +
      `Ongkos Kirim: ${deliveryFee === 0 ? "GRATIS" : formatRupiah(deliveryFee)}\n` +
      `TOTAL PEMBAYARAN: ${formatRupiah(grandTotal)}\n\n` +
      `Mohon dibantu konfirmasi pesanan dan metode pembayaran. Terima kasih!`
    );

    setOrderComplete(orderId);
    window.open(`https://wa.me/${PHARMACY_PROFILE.whatsapp.replace("+", "")}?text=${message}`, "_blank");
  };

  const handleCloseAndReset = () => {
    if (orderComplete) {
      onClearCart();
      setOrderComplete(null);
      setIsCheckoutMode(false);
    }
    onClose();
  };

  return (
    <div id="cart-drawer-backdrop" className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-900 text-white flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-['Outfit',sans-serif] font-bold text-slate-900 text-lg">
                Keranjang Belanja
              </h3>
              <p className="text-xs text-slate-500">
                {cartItems.length} produk terpilih
              </p>
            </div>
          </div>

          <button
            id="close-cart-drawer-btn"
            onClick={handleCloseAndReset}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-200/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {orderComplete ? (
            /* Completed view */
            <div className="text-center py-10 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-xl font-bold font-['Outfit',sans-serif] text-slate-900">
                Pesanan Terkirim ke WhatsApp!
              </h4>
              <p className="text-xs font-mono font-bold text-blue-900">
                No. Pesanan: {orderComplete}
              </p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Tim Apotek Care+ sedang menyiapkan produk Anda. Konfirmasi resi/kurir akan dikirim via chat WhatsApp.
              </p>
              <button
                onClick={handleCloseAndReset}
                className="w-full py-3 bg-blue-900 hover:bg-blue-800 text-white font-bold text-sm rounded-xl"
              >
                Belanja Lagi
              </button>
            </div>
          ) : cartItems.length === 0 ? (
            /* Empty Cart */
            <div className="text-center py-16 space-y-4">
              <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-800 text-base">Keranjang Anda Masih Kosong</h4>
                <p className="text-xs text-slate-500">Temukan vitamin, suplemen, dan perlengkapan P3K pilihan kami.</p>
              </div>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold rounded-xl"
              >
                Lihat Promo Produk
              </button>
            </div>
          ) : (
            <>
              {/* Free Shipping Progress Indicator */}
              <div className="bg-blue-50 border border-blue-200/70 rounded-xl p-3 text-xs text-blue-900">
                <div className="flex items-center justify-between font-semibold mb-1.5">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-blue-700" />
                    {subtotal >= 150000 
                      ? "Selamat! Anda Mendapatkan Bebas Ongkir" 
                      : `Tambah ${formatRupiah(150000 - subtotal)} lagi untuk Bebas Ongkir`}
                  </span>
                </div>
                <div className="w-full bg-blue-200 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-blue-800 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (subtotal / 150000) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-3">
                {cartItems.map((item) => (
                  <div 
                    key={item.product.id}
                    className="flex gap-3 bg-white border border-slate-200 rounded-xl p-3 shadow-2xs"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 object-contain bg-slate-50 rounded-lg p-1 border border-slate-100 shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h5 className="font-bold text-xs text-slate-800 line-clamp-1">
                          {item.product.name}
                        </h5>
                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="text-slate-400 hover:text-red-600 p-0.5"
                          title="Hapus"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-xs font-extrabold text-blue-900 mt-1">
                        {formatRupiah(item.product.discountPrice)}
                      </div>

                      {/* Quantity Selector */}
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-[11px] text-slate-400">{item.product.dosage}</span>
                        
                        <div className="flex items-center gap-2 border border-slate-200 rounded-lg bg-slate-50 px-1.5 py-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, -1)}
                            className="p-1 text-slate-500 hover:text-slate-900"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-slate-800 min-w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, 1)}
                            className="p-1 text-slate-500 hover:text-slate-900"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Checkout Info Input (if mode active) */}
              {isCheckoutMode && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 animate-in fade-in duration-200">
                  <h6 className="font-bold text-xs uppercase tracking-wider text-slate-700">
                    Informasi Pengiriman
                  </h6>

                  <input
                    type="text"
                    required
                    placeholder="Nama Penerima *"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />

                  <input
                    type="tel"
                    required
                    placeholder="Nomor WhatsApp Pemesan *"
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />

                  <textarea
                    rows={2}
                    placeholder="Alamat Pengantaran Lengkap..."
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />

                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">
                      Opsi Pengantaran:
                    </label>
                    <select
                      value={deliveryOption}
                      onChange={(e: any) => setDeliveryOption(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-900 focus:outline-none"
                    >
                      <option value="instant">🚀 Kurir Instan 24 Jam (Rp 15.000 / Gratis &gt;150rb)</option>
                      <option value="regular">📦 Kurir Reguler (Rp 10.000 / Gratis &gt;150rb)</option>
                    </select>
                  </div>
                </div>
              )}
            </>
          )}

        </div>

        {/* Footer with Calculations and Checkout */}
        {cartItems.length > 0 && !orderComplete && (
          <div className="p-5 border-t border-slate-200 bg-slate-50 space-y-3">
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Subtotal Produk:</span>
                <span className="font-semibold text-slate-800">{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Biaya Pengantaran:</span>
                <span className="font-semibold text-emerald-700">
                  {deliveryFee === 0 ? "GRATIS" : formatRupiah(deliveryFee)}
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Biaya:</span>
                <span className="text-base text-blue-900">{formatRupiah(grandTotal)}</span>
              </div>
            </div>

            {isCheckoutMode ? (
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setIsCheckoutMode(false)}
                  className="w-1/3 py-2.5 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Kembali
                </button>
                <button
                  id="btn-confirm-order-whatsapp"
                  onClick={handleCheckoutViaWhatsApp}
                  className="w-2/3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md flex items-center justify-center gap-1.5"
                >
                  <span>Pesan via WhatsApp</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="btn-proceed-checkout"
                onClick={() => setIsCheckoutMode(true)}
                className="w-full py-3 bg-blue-900 hover:bg-blue-800 active:bg-blue-950 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md flex items-center justify-center gap-2 transition-colors"
              >
                <span>Lanjut ke Pengiriman</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
