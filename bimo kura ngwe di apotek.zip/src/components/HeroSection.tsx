import React from "react";
import { 
  FileText, 
  MessageSquare, 
  ShieldCheck, 
  Clock, 
  Truck, 
  Award, 
  ArrowRight,
  CheckCircle2
} from "lucide-react";
import { motion } from "motion/react";

interface HeroSectionProps {
  onOpenPrescription: () => void;
  onOpenConsultation: () => void;
  onScrollToProducts: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenPrescription,
  onOpenConsultation,
  onScrollToProducts
}) => {
  return (
    <section id="hero-section" className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-slate-50 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-slate-200/70">
      {/* Decorative background grid and soft ambient blur */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f01a_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f01a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-[550px] h-[300px] bg-blue-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Main Headline, Copy & CTAs */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200/80 text-blue-900 text-xs sm:text-sm font-semibold tracking-wide shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-blue-600"></span>
              <span>Layanan Farmasi Modern & Berstandar Kemenkes RI</span>
            </div>

            {/* Main Headline */}
            <h1 
              id="hero-main-title" 
              className="font-['Outfit',sans-serif] text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.15] tracking-tight"
            >
              Solusi Kesehatan <span className="text-blue-900 relative inline-block">
                Terpercaya
                <svg className="absolute -bottom-1.5 left-0 w-full text-emerald-400/80" height="8" viewBox="0 0 200 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M1 5.5C45 2 155 2 199 5.5" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              </span> Keluarga Anda
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Tebus resep dokter dalam hitungan menit, konsultasi langsung dengan apoteker berlisensi, 
              dan nikmati jaminan <strong className="text-slate-900 font-semibold">100% obat asli</strong> siap antar 24 jam ke pintu rumah Anda.
            </p>

            {/* Quick Benefits Checkmarks */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-sm font-medium text-slate-700 max-w-2xl mx-auto text-left">
              <div className="flex items-center gap-2 bg-white/70 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Verifikasi Resep Apoteker Resmi</span>
              </div>
              <div className="flex items-center gap-2 bg-white/70 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Pengiriman Instan 24 Jam Siap Antar</span>
              </div>
              <div className="flex items-center gap-2 bg-white/70 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Jaminan Produk Segel & Izin BPOM</span>
              </div>
              <div className="flex items-center gap-2 bg-white/70 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200/60">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Konsultasi Dosis & Aturan Pakai Gratis</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
              <button
                id="hero-cta-tebus-resep"
                onClick={onOpenPrescription}
                className="group w-full sm:w-auto flex items-center justify-center gap-2.5 bg-blue-900 hover:bg-blue-800 active:bg-blue-950 text-white text-base font-semibold px-8 py-4 rounded-xl shadow-lg shadow-blue-900/20 hover:shadow-xl transition-all duration-200"
              >
                <FileText className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span>Tebus Resep Sekarang</span>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-cta-consult-pharmacist"
                onClick={onOpenConsultation}
                className="w-full sm:w-auto flex items-center justify-center gap-2.5 bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-800 text-base font-semibold px-7 py-4 rounded-xl border border-slate-300 shadow-xs hover:border-slate-400 transition-all duration-200"
              >
                <MessageSquare className="w-5 h-5 text-blue-600" />
                <span>Konsultasi Apoteker</span>
              </button>
            </div>

            {/* License & Pharmacist info badge */}
            <div className="pt-4 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500 border-t border-slate-200/80 max-w-xl mx-auto">
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-blue-700" />
                <span>No. SIA: 445/098/SIA/DPMPTSP/2023</span>
              </div>
              <span className="hidden sm:inline text-slate-300">•</span>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Apoteker Penanggung Jawab Ber-SIPA</span>
              </div>
            </div>

          </motion.div>

        </div>

        {/* Bottom Metrics Bar */}
        <div className="mt-14 pt-8 border-t border-slate-200/80 grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-100/70 text-blue-900 flex items-center justify-center shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-['Outfit',sans-serif] text-xl font-bold text-slate-900">30 Menit</div>
              <div className="text-xs text-slate-500">Estimasi Pengantaran Instan</div>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-100/70 text-emerald-800 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-['Outfit',sans-serif] text-xl font-bold text-slate-900">100% BPOM</div>
              <div className="text-xs text-slate-500">Resmi & Terverifikasi</div>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-100/70 text-amber-900 flex items-center justify-center shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="font-['Outfit',sans-serif] text-xl font-bold text-slate-900">12+ Apoteker</div>
              <div className="text-xs text-slate-500">Sarjana Farmasi Ber-SIPA</div>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-purple-100/70 text-purple-900 flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <div className="font-['Outfit',sans-serif] text-xl font-bold text-slate-900">24/7 Siaga</div>
              <div className="text-xs text-slate-500">Layanan Darurat Siang & Malam</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
