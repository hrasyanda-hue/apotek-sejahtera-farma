import React, { useState } from "react";
import { 
  X, 
  UserCheck, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  Phone, 
  ShieldCheck,
  Send
} from "lucide-react";
import { PHARMACY_PROFILE } from "../data/mockData";

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessToast: (msg: string) => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  onSuccessToast
}) => {
  const [patientName, setPatientName] = useState("");
  const [phone, setPhone] = useState("");
  const [symptomCategory, setSymptomCategory] = useState("Demam, Flu & Batuk");
  const [patientAgeGroup, setPatientAgeGroup] = useState("Dewasa");
  const [description, setDescription] = useState("");
  const [urgency, setUrgency] = useState<"normal" | "urgent">("normal");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [consultTicket, setConsultTicket] = useState<string | null>(null);

  if (!isOpen) return null;

  const symptomOptions = [
    "Demam, Flu & Batuk",
    "Pencernaan & Maag / Asam Lambung",
    "Alergi, Gatal & Masalah Kulit",
    "Nyeri Otot, Sendi & Sakit Kepala",
    "Konsultasi Dosis / Interaksi Obat Resep",
    "Rekomendasi Vitamin & Suplemen",
    "Kesehatan Ibu & Anak"
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !phone) {
      alert("Mohon masukkan nama dan nomor WhatsApp Anda.");
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/consultation/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: patientName,
          phone,
          symptoms: symptomCategory,
          ageCategory: patientAgeGroup,
          urgency,
          description
        })
      });

      const res = await response.json();
      const ticket = res?.data?.ticketId || "KONSUL-" + Math.floor(10000 + Math.random() * 90000);
      setConsultTicket(ticket);
      onSuccessToast(`Permintaan konsultasi ${ticket} terhubung ke Apoteker!`);
    } catch {
      const mockTicket = "KONSUL-" + Math.floor(10000 + Math.random() * 90000);
      setConsultTicket(mockTicket);
      onSuccessToast(`Permintaan konsultasi diterima oleh Apoteker Sejahtera Farma!`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenDirectWhatsApp = () => {
    const text = encodeURIComponent(
      `Halo Apoteker Sejahtera Farma, saya ingin konsultasi kesehatan:\n` +
      `• Tiket: ${consultTicket || "Konsul Baru"}\n` +
      `• Nama: ${patientName}\n` +
      `• Kategori Pasien: ${patientAgeGroup}\n` +
      `• Keluhan: ${symptomCategory}\n` +
      `• Detail Keluhan/Pertanyaan: ${description || "Mohon rekomendasi obat yang aman."}\n` +
      `• Tingkat Urgensi: ${urgency === "urgent" ? "Mendesak / Darurat 24 Jam" : "Konsultasi Reguler"}\n\n` +
      `Mohon saran dosis dan rekomendasi obatnya. Terima kasih!`
    );
    window.open(`https://wa.me/${PHARMACY_PROFILE.whatsapp.replace("+", "")}?text=${text}`, "_blank");
  };

  const resetAndClose = () => {
    setConsultTicket(null);
    setPatientName("");
    setPhone("");
    setDescription("");
    onClose();
  };

  return (
    <div id="consultation-modal-backdrop" className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden my-8 relative animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-blue-950 to-slate-900 text-white p-6 relative">
          <button
            id="close-consult-modal-btn"
            onClick={resetAndClose}
            className="absolute top-5 right-5 p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-2">
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            Konsultasi Privat & Gratis
          </div>
          <h3 className="font-['Outfit',sans-serif] text-2xl font-bold">
            Konsultasi dengan Apoteker
          </h3>
          <p className="text-sm text-slate-300 mt-1">
            Dapatkan saran pemilihan obat bebas, dosis tepat, dan penanganan keluhan pertama secara aman.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          {consultTicket ? (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 bg-blue-100 text-blue-900 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10 text-emerald-600" />
              </div>

              <div>
                <h4 className="text-2xl font-bold font-['Outfit',sans-serif] text-slate-900">
                  Konsultasi Terdaftar!
                </h4>
                <p className="text-xs font-mono font-bold text-blue-900 mt-1">
                  Nomor Antrean: {consultTicket}
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left text-sm space-y-2 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-slate-500">Apoteker Jaga:</span>
                  <span className="font-bold text-slate-800">apt. Sarah Pradipta, S.Farm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Estimasi Respons:</span>
                  <span className="font-bold text-emerald-600">&lt; 3 Menit</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Topik:</span>
                  <span className="font-medium text-slate-800">{symptomCategory}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-3">
                <button
                  id="btn-wa-consult-chat"
                  onClick={handleOpenDirectWhatsApp}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-xl text-sm shadow-md transition-colors flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Mulai Chat di WhatsApp</span>
                </button>
                <button
                  onClick={resetAndClose}
                  className="border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold px-6 py-3 rounded-xl text-sm transition-colors"
                >
                  Tutup
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Nama Anda <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="consult-patient-name"
                    type="text"
                    required
                    placeholder="Nama lengkap"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Nomor WhatsApp <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="consult-patient-phone"
                    type="tel"
                    required
                    placeholder="0812xxxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Kategori Keluhan / Topik Konsultasi
                </label>
                <select
                  id="consult-symptom-category"
                  value={symptomCategory}
                  onChange={(e) => setSymptomCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                >
                  {symptomOptions.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Kelompok Usia Pasien
                  </label>
                  <select
                    id="consult-age-group"
                    value={patientAgeGroup}
                    onChange={(e) => setPatientAgeGroup(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="Bayi / Balita (0-5 Thn)">Bayi / Balita (0-5 Thn)</option>
                    <option value="Anak-anak (6-12 Thn)">Anak-anak (6-12 Thn)</option>
                    <option value="Remaja (13-18 Thn)">Remaja (13-18 Thn)</option>
                    <option value="Dewasa">Dewasa</option>
                    <option value="Lansia (&gt; 60 Thn)">Lansia (&gt; 60 Thn)</option>
                    <option value="Ibu Hamil / Menyusui">Ibu Hamil / Menyusui</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Tingkat Urgensi
                  </label>
                  <select
                    id="consult-urgency"
                    value={urgency}
                    onChange={(e: any) => setUrgency(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="normal">Normal (Konsultasi Biasa)</option>
                    <option value="urgent">🚨 Butuh Cepat / Darurat 24 Jam</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Deskripsi Keluhan / Riwayat Obat
                </label>
                <textarea
                  id="consult-description"
                  rows={3}
                  placeholder="Ceritakan gejala yang dirasakan sejak kapan, obat apa yang sudah diminum, atau pertanyaan seputar aturan pakai..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={resetAndClose}
                  className="w-1/3 py-3 rounded-xl border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  id="btn-submit-consult-form"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-2/3 py-3 bg-blue-900 hover:bg-blue-800 active:bg-blue-950 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span>Menghubungkan...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-emerald-400" />
                      <span>Kirim ke Apoteker</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
