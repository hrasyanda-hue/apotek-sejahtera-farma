import { Product, ServiceItem } from "../types";

export const PRODUCTS_DATA: Product[] = [
  {
    id: "prod-1",
    name: "Vitamin C 1000mg + Zinc Complex",
    category: "Vitamin & Suplemen",
    originalPrice: 85000,
    discountPrice: 65000,
    discountPercentage: 24,
    dosage: "1000 mg",
    packaging: "Botol isi 30 Kaplet Salut",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80",
    badge: "Promo Mingguan",
    rating: 4.9,
    soldCount: 1420,
    inStock: true,
    description: "Meningkatkan daya tahan tubuh dan perlindungan antioksidan harian dengan formulasi ramah lambung (non-acidic).",
    bpomNumber: "POM SD 211568901"
  },
  {
    id: "prod-2",
    name: "Kotak P3K Lengkap Family First Aid Kit",
    category: "Peralatan Medis",
    originalPrice: 165000,
    discountPrice: 129000,
    discountPercentage: 22,
    dosage: "Isi 18 Item Medis Lengkap",
    packaging: "Tas Medis Water-resistant",
    image: "https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=600&q=80",
    badge: "Wajib di Rumah",
    rating: 4.8,
    soldCount: 890,
    inStock: true,
    description: "Perlengkapan pertolongan pertama bersertifikat Kemenkes: kasa steril, antiseptik povidone, perban elastis, plester, gunting medis.",
    bpomNumber: "KEMENKES RI AKD 10903810231"
  },
  {
    id: "prod-3",
    name: "Minyak Ikan Omega-3 Ultra Pure EPA/DHA",
    category: "Vitamin & Suplemen",
    originalPrice: 210000,
    discountPrice: 159000,
    discountPercentage: 24,
    dosage: "1200 mg (EPA 360mg, DHA 240mg)",
    packaging: "Botol 60 Softgels",
    image: "https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=600&q=80",
    badge: "Terlaris",
    rating: 5.0,
    soldCount: 2310,
    inStock: true,
    description: "Mendukung kesehatan sirkulasi jantung, elastisitas pembuluh darah, dan fokus kognitif dari ikan laut dalam murni.",
    bpomNumber: "POM SI 194310551"
  },
  {
    id: "prod-4",
    name: "Termometer Digital Inframerah Non-Contact",
    category: "Peralatan Medis",
    originalPrice: 195000,
    discountPrice: 145000,
    discountPercentage: 26,
    dosage: "Sensor Presisi Tinggi 0.1°C",
    packaging: "Unit + 2x Baterai AAA + Pouch",
    image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=600&q=80",
    badge: "Promo Mingguan",
    rating: 4.9,
    soldCount: 670,
    inStock: true,
    description: "Pengukuran suhu tubuh dalam 1 detik dengan akurasi klinis tinggi, layar LCD tiga warna penanda demam.",
    bpomNumber: "KEMENKES RI AKL 20901912400"
  },
  {
    id: "prod-5",
    name: "Madu Imunostimulan Propolis & Habbatussauda",
    category: "Herbal & Alami",
    originalPrice: 98000,
    discountPrice: 79000,
    discountPercentage: 19,
    dosage: "250 ml",
    packaging: "Botol Kaca Food Grade",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80",
    badge: "Herbal Pilihan",
    rating: 4.8,
    soldCount: 1150,
    inStock: true,
    description: "Madu hutan murni diperkaya ekstrak propolis trigona dan habbatussauda untuk melegakan tenggorokan dan batuk.",
    bpomNumber: "POM TR 193627881"
  },
  {
    id: "prod-6",
    name: "Masker Bedah Medis 3-Ply Earloop BFE 99%",
    category: "Perlindungan & Higienis",
    originalPrice: 45000,
    discountPrice: 32000,
    discountPercentage: 29,
    dosage: "3 Lapisan Filtrasi Bakteri",
    packaging: "Box isi 50 Pcs",
    image: "https://images.unsplash.com/photo-1586942593568-29361efcd571?auto=format&fit=crop&w=600&q=80",
    badge: "Hemat 29%",
    rating: 4.9,
    soldCount: 4500,
    inStock: true,
    description: "Masker medis standar rumah sakit dengan efisiensi filtrasi bakteri 99%, sirkulasi udara lega dan tali lembut.",
    bpomNumber: "KEMENKES RI AKD 21603020087"
  }
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "tebus-resep",
    title: "Tebus Resep Online",
    description: "Unggah foto resep dokter Anda, apoteker kami langsung memverifikasi keabsahan & dosis, obat dikemas steril dan dikirim.",
    iconName: "FileText",
    badgeText: "Verifikasi < 5 Menit",
    features: [
      "Verifikasi langsung Apoteker (SIPA)",
      "Kemasan tertutup rapat & privacy seal",
      "Pemberian etiket aturan minum detail"
    ],
    actionLabel: "Tebus Resep Sekarang"
  },
  {
    id: "konsultasi-apoteker",
    title: "Konsultasi Apoteker",
    description: "Konsultasikan keluhan ringan, interaksi antar-obat, efek samping, dan pemilihan suplemen secara gratis dan privat.",
    iconName: "UserCheck",
    badgeText: "Gratis & Ramah",
    features: [
      "Apoteker Berpengalaman S.Farm, Apt",
      "Rekomendasi obat bebas & herbal aman",
      "Edukasi cara pakai alat kesehatan"
    ],
    actionLabel: "Tanya Apoteker"
  },
  {
    id: "cek-kesehatan",
    title: "Cek Kesehatan",
    description: "Pemeriksaan parameter kesehatan mandiri cepat dan akurat di apotek untuk deteksi dini dan pemantauan rutin keluarga.",
    iconName: "Activity",
    badgeText: "Hasil Instan",
    features: [
      "Cek Tensi Darah & Heart Rate",
      "Cek Gula Darah, Kolesterol, & Asam Urat",
      "Konsultasi hasil langsung bersama Apoteker"
    ],
    actionLabel: "Lihat Layanan Cek"
  },
  {
    id: "pesan-antar-24jam",
    title: "Pesan Antar 24 Jam",
    description: "Layanan darurat pengiriman obat siang dan malam dengan kurir terlatih serta tas khusus untuk menjaga stabilitas obat.",
    iconName: "Clock",
    badgeText: "Siaga 24/7",
    features: [
      "Pengantaran Instan 30-45 Menit",
      "Cold-chain box untuk insulin & sirup khusus",
      "Tersedia metode COD & Transfer QRIS"
    ],
    actionLabel: "Pesan Antar 24 Jam"
  }
];

export const HEALTH_CHECK_ITEMS = [
  {
    name: "Pemeriksaan Tekanan Darah (Tensi)",
    price: "GRATIS",
    duration: "2 Menit",
    description: "Deteksi risiko hipertensi dan pemantauan ritme denyut nadi.",
    recommendedFor: "Semua usia, minimal 1x sebulan"
  },
  {
    name: "Tes Gula Darah Sewaktu (GDS)",
    price: "Rp 15.000",
    duration: "1 Menit",
    description: "Pemeriksaan kadar glukosa darah dengan alat uji terstandarisasi klinis.",
    recommendedFor: "Penderita diabetes / skrining rutin"
  },
  {
    name: "Tes Kolesterol Total",
    price: "Rp 25.000",
    duration: "3 Menit",
    description: "Skrining profil lipid untuk pencegahan penyakit kardiovaskular.",
    recommendedFor: "Usia di atas 25 tahun / pola makan tinggi lemak"
  },
  {
    name: "Tes Asam Urat (Uric Acid)",
    price: "Rp 20.000",
    duration: "2 Menit",
    description: "Pemeriksaan kadar asam urat untuk deteksi nyeri persendian / gout.",
    recommendedFor: "Keluhan nyeri sendi jari/kaki"
  },
  {
    name: "Paket Skrining Komplit (Tensi + Gula + Kolesterol + Asam Urat)",
    price: "Rp 50.000",
    duration: "5 Menit",
    description: "Paket hemat pemeriksaan 4 indikator kesehatan utama plus kartu pantau gratis.",
    recommendedFor: "Pemeriksaan berkala keluarga & lansia"
  }
];

export const PHARMACY_PROFILE = {
  name: "Apotek Sejahtera Farma",
  tagline: "Solusi Kesehatan Terpercaya Keluarga Anda",
  address: "Jl. Kesehatan Raya No. 45, Kebayoran Baru, Jakarta Selatan 12180",
  operationalHours: "Buka 24 Jam Setiap Hari (Senin - Minggu)",
  phone: "(021) 555-SEJAHTERA (7352)",
  whatsapp: "+6281222737587",
  displayWhatsapp: "0812-2273-7587",
  email: "layanan@sejahterafarma.id",
  siaNumber: "SIA: 445/098/SIA/DPMPTSP/2023",
  sipaLeadPharmacist: "apt. Sarah Pradipta, S.Farm (SIPA: 19890415/SIPA_31.74/2023/2001)",
  googleMapsUrl: "https://maps.google.com/?q=Jakarta"
};
