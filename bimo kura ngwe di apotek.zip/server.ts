import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

interface Product {
  id: string;
  name: string;
  category: string;
  originalPrice: number;
  discountPrice: number;
  discountPercentage: number;
  dosage: string;
  packaging: string;
  image: string;
  badge?: string;
  rating: number;
  soldCount: number;
  inStock: boolean;
  description: string;
  bpomNumber: string;
}

const PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "Vitamin C 1000mg + Zinc Complex",
    category: "Vitamin & Suplemen",
    originalPrice: 85000,
    discountPrice: 65000,
    discountPercentage: 24,
    dosage: "1000 mg",
    packaging: "Botol isi 30 Kaplet",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80",
    badge: "Promo Mingguan",
    rating: 4.9,
    soldCount: 1420,
    inStock: true,
    description: "Meningkatkan daya tahan tubuh dan perlindungan antioksidan harian dengan formulasi non-asam di lambung.",
    bpomNumber: "POM SD 211568901"
  },
  {
    id: "prod-2",
    name: "Kotak P3K Lengkap Family Care First Aid",
    category: "Peralatan Medis",
    originalPrice: 165000,
    discountPrice: 129000,
    discountPercentage: 22,
    dosage: "Isi 18 Item Medis",
    packaging: "Tas Medis Anti Air",
    image: "https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=600&q=80",
    badge: "Wajib di Rumah",
    rating: 4.8,
    soldCount: 890,
    inStock: true,
    description: "Perlengkapan pertolongan pertama lengkap bersertifikat Kemenkes: kasa steril, antiseptik, perban elastis, plester, gunting medis.",
    bpomNumber: "KEMENKES RI AKD 10903810231"
  },
  {
    id: "prod-3",
    name: "Minyak Ikan Omega-3 Ultra Pure EPA/DHA",
    category: "Vitamin & Suplemen",
    originalPrice: 210000,
    discountPrice: 159000,
    discountPercentage: 24,
    dosage: "1200 mg",
    packaging: "Botol 60 Softgels",
    image: "https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=600&q=80",
    badge: "Terlaris",
    rating: 5.0,
    soldCount: 2310,
    inStock: true,
    description: "Mendukung kesehatan jantung, fungsi otak, dan elastisitas pembuluh darah dengan minyak ikan murni laut dalam bebas merkuri.",
    bpomNumber: "POM SI 194310551"
  },
  {
    id: "prod-4",
    name: "Termometer Digital Inframerah Dahi & Telinga",
    category: "Peralatan Medis",
    originalPrice: 195000,
    discountPrice: 145000,
    discountPercentage: 26,
    dosage: "Sensor Presisi 0.1°C",
    packaging: "Unit + Baterai + Pouch",
    image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=600&q=80",
    badge: "Promo Mingguan",
    rating: 4.9,
    soldCount: 670,
    inStock: true,
    description: "Pengukuran suhu instan dalam 1 detik tanpa sentuhan langsung, layar LCD backlight 3 warna penanda demam.",
    bpomNumber: "KEMENKES RI AKL 20901912400"
  },
  {
    id: "prod-5",
    name: "Madu Herbal Imunostimulan & Propolis Plus",
    category: "Herbal & Alami",
    originalPrice: 98000,
    discountPrice: 79000,
    discountPercentage: 19,
    dosage: "250 ml",
    packaging: "Botol Kaca Higienis",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80",
    badge: "Herbal Alami",
    rating: 4.8,
    soldCount: 1150,
    inStock: true,
    description: "Kombinasi madu hutan murni, habbatussauda, dan ekstrak propolis untuk meredakan radang tenggorokan & flu.",
    bpomNumber: "POM TR 193627881"
  },
  {
    id: "prod-6",
    name: "Masker Medis Bedah 3-Ply Earloop BFE 99%",
    category: "Perlindungan & Higienis",
    originalPrice: 45000,
    discountPrice: 32000,
    discountPercentage: 29,
    dosage: "3 Lapisan Filtrasi",
    packaging: "Kotak isi 50 Pcs",
    image: "https://images.unsplash.com/photo-1586942593568-29361efcd571?auto=format&fit=crop&w=600&q=80",
    badge: "Hemat 29%",
    rating: 4.9,
    soldCount: 4500,
    inStock: true,
    description: "Filtrasi bakteri & partikel mikro hingga 99%, bahan lembut nyaman bernapas, kawat hidung fleksibel.",
    bpomNumber: "KEMENKES RI AKD 21603020087"
  }
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "15mb" }));

  // API Routes
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      name: "Apotek Sejahtera Farma API",
      timestamp: new Date().toISOString(),
      pharmacistOnDuty: "apt. Sarah Pradipta, S.Farm (SIPA: 19890415/SIPA_31.74/2023/2001)",
      pharmacyStatus: "Buka 24 Jam"
    });
  });

  app.get("/api/products", (_req, res) => {
    res.json({
      success: true,
      data: PRODUCTS
    });
  });

  app.post("/api/prescription/redeem", (req, res) => {
    const { patientName, phone, deliveryAddress, deliveryType, notes, allergyInfo } = req.body;

    if (!patientName || !phone) {
      return res.status(400).json({
        success: false,
        message: "Nama pasien dan nomor WhatsApp wajib diisi."
      });
    }

    const prescriptionId = "RX-" + Math.floor(100000 + Math.random() * 900000);
    
    return res.json({
      success: true,
      data: {
        prescriptionId,
        patientName,
        phone,
        deliveryAddress: deliveryAddress || "Ambil di Apotek (Drive-thru)",
        deliveryType: deliveryType || "instant",
        notes,
        allergyInfo: allergyInfo || "Tidak ada riwayat alergi",
        status: "Memverifikasi Resep",
        estimatedTime: deliveryType === "instant" ? "30 - 45 Menit" : "1 - 2 Jam",
        assignedPharmacist: "apt. Sarah Pradipta, S.Farm",
        createdAt: new Date().toISOString()
      },
      message: "Resep Anda telah berhasil dikirim ke Apoteker Sejahtera Farma. Tim kami akan segera memverifikasi via WhatsApp."
    });
  });

  app.post("/api/consultation/submit", (req, res) => {
    const { name, phone, symptoms, ageCategory, urgency } = req.body;

    if (!name || !phone) {
      return res.status(400).json({
        success: false,
        message: "Nama dan nomor kontak wajib diisi."
      });
    }

    const ticketId = "KONSUL-" + Math.floor(10000 + Math.random() * 90000);

    return res.json({
      success: true,
      data: {
        ticketId,
        name,
        phone,
        symptoms,
        ageCategory,
        urgency: urgency || "normal",
        status: "Menghubungkan ke Apoteker",
        estimatedWait: "< 3 Menit"
      },
      message: "Permintaan konsultasi diterima. Apoteker kami akan menghubungi nomor WhatsApp Anda dalam hitungan menit."
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Apotek Sejahtera Farma Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
